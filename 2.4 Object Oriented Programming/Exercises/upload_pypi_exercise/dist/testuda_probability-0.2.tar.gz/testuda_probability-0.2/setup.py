from setuptools import setup

setup(name='testuda_probability',
      version='0.2',
      description='Gaussian distributions',
      packages=['testuda_probability'],
      zip_safe=False)
